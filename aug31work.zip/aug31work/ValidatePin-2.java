import java.util.Scanner;

public class ValidatePin {

    public static void main(String[] args) {
        int PIN = 1234;
        System.out.print("Enter PIN: ");
        Scanner console = new Scanner(System.in);
        int guess = console.nextInt();
        
        
        while (true) {
            if (PIN != guess){
             System.out.println("Invalid PIN, try again: ");
             guess = console.nextInt();}
            else{
            break;}
            
            
        }
    }
}
